<?php
/**
 * Magiccart 
 * @category    Magiccart 
 * @copyright   Copyright (c) 2014 Magiccart (http://www.magiccart.net/) 
 * @license     http://www.magiccart.net/license-agreement.html
 * @Author: DOng NGuyen<nguyen@dvn.com>
 * @@Create Date: 2017-08-03 20:44:49
 * @@Modify Date: 2017-08-03 20:44:56
 * @@Function:
 */
namespace Magiccart\Cms\Block;
use Magiccart\Core\Block\Template; // use Magiccart\Core\Block\ShortcodeAuto as CoreShortcode;

// How to use: add to function in theme: $block = new Magiccart\Cms\Block\Block;
class Block extends Template{
    public function initShortcode( $atts ){
        if (!isset($atts['text']) || !$atts['text']) return ;
        $value   = get_option('magiccart_block', '');
        $value   = json_decode($value, true);
        $text    = $atts['text'];
        if(isset($value[$text]['value'])){
            if($value[$text]['status']){
                $editorText = $value[$text]['value'];
                print_r(wp_kses_post( $editorText));
            }
        }
    }
}
