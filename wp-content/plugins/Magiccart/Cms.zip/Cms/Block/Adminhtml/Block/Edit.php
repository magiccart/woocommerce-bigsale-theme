<?php
namespace Magiccart\Cms\Block\Adminhtml\Block;

use Magiccart\Core\Block\Adminhtml\Template;

class Edit extends Template{
    protected $_template = 'edit.phtml';
    
}
